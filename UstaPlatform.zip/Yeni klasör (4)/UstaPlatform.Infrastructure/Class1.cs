﻿namespace UstaPlatform.Infrastructure
{
    public class Class1
    {

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UstaPlatform.Domain.Entities
{
    public class Talep
    {
        public Guid Id { get; init; } = Guid.NewGuid();
        public Vatandas Vatandas { get; set; }
        public string Aciklama { get; set; }
        public DateTime Tarih { get; set; } = DateTime.Now;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UstaPlatform.Domain.Entities
{
    public class IsEmri
    {
        public Guid Id { get; init; } = Guid.NewGuid();
        public Usta Usta { get; set; }
        public Talep Talep { get; set; }
        public decimal Fiyat { get; set; }
        public DateTime Tarih { get; set; }
    }
}

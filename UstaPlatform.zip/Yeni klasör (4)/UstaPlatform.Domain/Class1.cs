﻿namespace UstaPlatform.Domain
{
    public class Class1
    {

    }
}

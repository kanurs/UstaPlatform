﻿using UstaPlatform.Pricing;

namespace LoyaltyDiscountRule
{
    public class LoyaltyDiscountRule : IPricingRule
    {
        public decimal Hesapla(decimal mevcutFiyat)
        {
            // Sadık müşterilere %10 indirim uygula
            return mevcutFiyat * 0.9m;
        }
    }
}

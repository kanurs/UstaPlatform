﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;


namespace UstaPlatform.Pricing
{
    public class PricingEngine
    {
        private readonly List<IPricingRule> _kurallar = new();

        public PricingEngine(string eklentiKlasoru)
        {
            foreach (var dll in Directory.GetFiles(eklentiKlasoru, "*.dll"))
            {
                var asm = Assembly.LoadFrom(dll);
                var ruleTypes = asm.GetTypes()
                    .Where(t => typeof(IPricingRule).IsAssignableFrom(t) && !t.IsInterface);

                foreach (var t in ruleTypes)
                {
                    var instance = (IPricingRule)Activator.CreateInstance(t)!;
                    _kurallar.Add(instance);
                }
            }
        }

        public decimal Hesapla(decimal temelFiyat)
        {
            decimal sonuc = temelFiyat;

            foreach (var kural in _kurallar)
                sonuc = kural.Hesapla(sonuc);

            return sonuc;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UstaPlatform.Pricing
{
    public interface IPricingRule
    {
        decimal Hesapla(decimal mevcutFiyat);
    }
}

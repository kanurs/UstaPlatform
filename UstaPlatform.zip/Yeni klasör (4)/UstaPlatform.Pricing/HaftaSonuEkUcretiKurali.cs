﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UstaPlatform.Pricing
{
    public class HaftaSonuEkUcretiKurali : IPricingRule
    {
        public decimal Hesapla(decimal mevcutFiyat)
        {
            var bugun = DateTime.Now.DayOfWeek;

            if (bugun == DayOfWeek.Saturday || bugun == DayOfWeek.Sunday)
                return mevcutFiyat * 1.2m;

            return mevcutFiyat;
        }
    }
}

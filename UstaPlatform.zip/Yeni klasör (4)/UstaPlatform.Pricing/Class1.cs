﻿namespace UstaPlatform.Pricing
{
    public class Class1
    {

    }
}

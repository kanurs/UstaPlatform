﻿using UstaPlatform.Domain.Entities;
using UstaPlatform.Pricing;

Console.WriteLine("UstaPlatform Başlatılıyor...\n");

// Vatandaş oluştur
var vatandas = new Vatandas { Ad = "Ahmet" };

// Talep oluştur
var talep = vatandas.TalepOlustur("Musluk tamiri");

// Usta oluştur
var usta = new Usta
{
    Ad = "Mehmet Usta",
    UzmanlikAlani = "Tesisat",
    Puan = 4.8,
    GunlukIsYuku = 2
};

// Fiyat motoru (mevcut klasörden eklentileri yükler)
var fiyatMotoru = new PricingEngine(AppDomain.CurrentDomain.BaseDirectory);

// Temel fiyat
decimal temelFiyat = 500m;

// Kuralları uygula
decimal nihaiFiyat = fiyatMotoru.Hesapla(temelFiyat);

// İş emrini oluştur
var isEmri = new IsEmri
{
    Usta = usta,
    Talep = talep,
    Fiyat = nihaiFiyat,
    Tarih = DateTime.Now
};

// Çıktıyı yazdır
Console.WriteLine($"Vatandaş: {talep.Vatandas.Ad}");
Console.WriteLine($"Usta: {usta.Ad}");
Console.WriteLine($"Talep: {talep.Aciklama}");
Console.WriteLine($"Hesaplanan Fiyat: {nihaiFiyat:C}");
Console.WriteLine($"İş Emri Tarihi: {isEmri.Tarih}");
Console.WriteLine("\nİş Emri Oluşturuldu ✅");
